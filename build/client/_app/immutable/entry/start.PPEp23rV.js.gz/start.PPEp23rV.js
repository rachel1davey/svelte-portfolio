import{l as o,a as r}from"../chunks/D9JS1Wmc.js";export{o as load_css,r as start};
